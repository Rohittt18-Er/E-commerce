import React from "react";

const PaginationComponent = () => {
  return <div>PaginationComponent</div>;
};

export default PaginationComponent;
