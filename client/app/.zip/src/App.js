
import  Router  from './router';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
<Router/>
  );
}

export default App;
