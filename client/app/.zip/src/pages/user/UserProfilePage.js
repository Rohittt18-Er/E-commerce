import React from "react";

const UserProfilePage = () => {
  return <div>UserProfilePage</div>;
};

export default UserProfilePage;
